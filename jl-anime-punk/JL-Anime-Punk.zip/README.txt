﻿JL ANIME PUNK — эффекты для DaVinci Resolve
Проверено в DaVinci Resolve Studio 21.2 (Windows).

УСТАНОВКА
  1. Дважды щёлкни JL-Anime-Punk.drfx — DaVinci Resolve предложит установить пак, нажми Install.
     (Или перетащи файл в окно DaVinci Resolve.)
  2. Дважды щёлкни Oswald-Bold.ttf и нажми «Установить» — шрифт нужен титру «JL Надпись на бумаге».
  3. Перезапусти DaVinci Resolve.
  По желанию: скопируй «JL перемешать.py» в папку скриптов
     Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Scripts\Edit

ГДЕ ИСКАТЬ
  Effects → Fusion Effects:              JL Герой, JL Постер, JL Силуэт, JL Маркер
  Video Transitions → Fusion Transitions: JL Вспышка, JL Разлом, JL Мазки
  Titles → Fusion Titles:                 JL Надпись на бумаге
  Generators → Fusion Generators:         JL Клочки

МАСКА ГЕРОЯ (Герой, Постер, Силуэт, Вспышка, Разлом)
  Эффекты берут вырез героя из Magic Mask самого клипа:
  1. Отрежь кусок и кинь на него эффект.
  2. Выдели кусок → страница Fusion. Выдели MediaIn1, нажми Shift+Space → Magic Mask.
     Цепочка должна стать MediaIn1 → Magic Mask → MediaOut1.
  3. В Magic Mask сними галочку «Post-Multiply Image».
  4. Отметь героя во вьюере и протрекай кусок.
  5. Вернись на Edit — эффект уже работает по твоему выделению.
  Для переходов Вспышка и Разлом: отрежь бритвой кадры у склейки в отдельные куски (9 до и 9 после),
  сделай на них Magic Mask, кинь переход на склейку и выбери «Силуэты: Мой Magic Mask».

СКРИПТ «JL перемешать»
  Workspace → Scripts → JL перемешать: раздаёт новый «Вариант» всем эффектам JL на таймлайне,
  чтобы ролики не повторяли друг друга.

НА 4K
  Эффекты считаются в разрешении таймлайна. Для плавного просмотра на 4K включи
  Playback → Render Cache → Smart.

Шрифт Oswald — SIL Open Font License (см. «Oswald OFL.txt»). Текстуры бумаги — TextureCan, CC0.
