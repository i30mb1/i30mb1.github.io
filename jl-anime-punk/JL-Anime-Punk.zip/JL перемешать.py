# JL Anime Punk: перемешать — новые «Варианты» всем эффектам JL на текущем таймлайне, чтобы ролик не повторял прошлый.
# Запуск: Workspace → Scripts → «JL перемешать». Что поменялось — в Workspace → Console.
# Меняет зерно случайности у переходов (Вспышка, Разлом, Мазки), Надписи на бумаге, Силуэта, Героя, Постера и Клочков:
# другой прицел, мазки, обрыв бумаги, клинья, каракули, наклоны. Рисунок, который ты выбрал в JL Маркер, не трогает.
# Не понравился один — покрути его «Вариант» руками; старые значения пишутся в консоль, чтобы можно было вернуть.
import random

KEYS = {'Вспышка': 'Variant', 'Разлом': 'Variant', 'Силуэт': 'Variant', 'Герой': 'Variant', 'Постер': 'Variant',
        'Мазки': 'Seed', 'Надпись на бумаге': 'Seed', 'Клочки': 'Seed'}
SEEDS = {p + ' ' + n: k for n, k in KEYS.items() for p in ('JL', 'AP')}     # AP — прежние названия тех же эффектов


def log(*a):
    print('[JL перемешать]', *a)


def comps_of(item):
    """(имя шаблона, композиция) для перехода/титра/генератора и для эффектов на клипе"""
    out = []
    name = item.GetName() or ''
    if name in SEEDS:
        for i in range(1, int(item.GetFusionCompCount() or 0) + 1):
            out.append((name, item.GetFusionCompByIndex(i)))
    if item.GetType() != 'transition':
        for e in item.GetEffects('fusion') or []:
            n = (e.GetInfo() or {}).get('name', '')
            if n in SEEDS:
                out.append((n, e.GetFusionComp()))
    return out


def run(resolve):
    proj = resolve.GetProjectManager().GetCurrentProject()
    tl = proj.GetCurrentTimeline()
    rng = random.Random()
    changed = 0
    for t in range(1, tl.GetTrackCount('video') + 1):
        for it in tl.GetItemListInTrack('video', t) or []:
            for name, c in comps_of(it):
                ctrl = c.FindTool('Ctrl') if c else None
                key = SEEDS[name]
                if not ctrl or ctrl.GetInput(key) is None:
                    continue
                old = ctrl.GetInput(key)
                new = rng.randint(1, 50)
                while new == old:
                    new = rng.randint(1, 50)
                ctrl.SetInput(key, new)
                changed += 1
                log(f'V{t} {it.GetStart()}: {name} — вариант {int(old or 0)} → {new}')
    log(f'готово: перемешано {changed}')
    return changed


if __name__ == '__main__' and 'resolve' in globals():
    run(resolve)
